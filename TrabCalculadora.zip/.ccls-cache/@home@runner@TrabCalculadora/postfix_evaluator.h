#ifndef POSTFIX_EVALUATOR_H
#define POSTFIX_EVALUATOR_H

double evaluatePostfix(char* expression);

#endif
